"""Terminal interface for Food Waste Diary (kept alongside the Streamlit UI)."""
from datetime import date
from pathlib import Path
from food_waste_diary.core import (
    validate_record, search_records, summarize, CATEGORIES, REASONS,
)
from food_waste_diary.storage import Storage
from food_waste_diary.reports import export_csv, export_summary, make_chart
from food_waste_diary.logging_config import get_logger
from food_waste_diary.insights import build_insights

logger = get_logger(__name__)

ROOT = Path(__file__).resolve().parent
storage = Storage(ROOT / "data")
records = storage.load()


def header():
    print("\n" + "=" * 60 + "\n       FOOD WASTE DIARY | LOCAL ANALYTICS\n" + "=" * 60)


def input_nonempty(prompt):
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("Please enter a value; blank input is not accepted.")


def add_record():
    print("\n-- Add a record --")
    name = input_nonempty("Food name: ")
    print("Categories: " + ", ".join(CATEGORIES))
    category = input_nonempty("Category: ")
    print("Reasons: " + ", ".join(REASONS))
    reason = input("Reason [Other]: ").strip() or "Other"
    quantity = input_nonempty("Discarded quantity (kg): ")
    entry_date = input(f"Date [default {date.today()}]: ").strip() or date.today().isoformat()
    try:
        record = validate_record(name, category, quantity, reason, entry_date)
        records.append(record)
        storage.save(records)
        print("Saved record successfully to SQLite, JSON and CSV.")
        logger.info("CLI record added: %s", record["id"])
    except ValueError as exc:
        print(f"Validation error: {exc}")
        logger.warning("CLI validation rejected a record: %s", exc)


def list_records(items=None):
    items = records if items is None else items
    if not items:
        print("No records found.")
        return
    print(f"\n{'DATE':<12} {'FOOD':<22} {'CATEGORY':<12} {'KG':>8}  REASON")
    print("-" * 78)
    for record in items:
        print(f"{record['entry_date']:<12} {record['food_name'][:21]:<22} {record['category']:<12} {float(record['quantity_kg']):>8.3f}  {record['reason']}")
    print(f"Showing {len(items)} record(s).")


def analytics():
    result = summarize(records)
    print("\n-- Executive summary --")
    print(f"Records: {result['entries']} | Total: {result['total_kg']:.3f} kg | Average: {result['average_kg']:.3f} kg")
    print(f"Overall waste status: {result['status']}")
    print("\n-- Waste reduction insights --")
    for insight in build_insights(records):
        print("  *", insight)
    if result["by_category"]:
        print("\nWaste by category:")
        for category, kg in result["by_category"].items():
            print(f"  {category:<12} {kg:>8.3f} kg")
        print(f"\nHighest waste category: {next(iter(result['by_category'].items()))[0]}")
        print("\nDaily trend:")
        for day, kg in result["by_day"].items():
            print(f"  {day}: {kg:.3f} kg")
    else:
        print("Add entries to see analytics.")
    if result["warnings"]:
        print("\nTHRESHOLD WARNINGS:")
        for warning in result["warnings"]:
            print("  WARNING:", warning)
    else:
        print("\nNo threshold warnings.")


def search():
    keyword = input("Search food/reason keyword (blank = all): ")
    category = input("Category (or All): ").strip().title() or "All"
    if category not in ["All"] + CATEGORIES:
        print("Unknown category; showing all categories.")
        category = "All"
    list_records(search_records(records, keyword, category))


def import_csv():
    path = input_nonempty("CSV file path: ")
    imported, errors = storage.import_csv(path)
    if imported:
        records.extend(imported)
        storage.save(records)
    print(f"Imported {len(imported)} valid row(s).")
    for error in errors:
        print(" -", error)


def exports():
    output = ROOT / "exports"
    print("\n1. Export records CSV\n2. Summary Markdown\n3. Summary TXT\n4. Chart PNG")
    choice = input("Choose: ").strip()
    try:
        if choice == "1":
            print("Saved:", export_csv(records, output / "food_waste_export.csv"))
        elif choice == "2":
            print("Saved:", export_summary(records, output / "summary.md", "md"))
        elif choice == "3":
            print("Saved:", export_summary(records, output / "summary.txt", "txt"))
        elif choice == "4":
            path = make_chart(records, output / "category_chart.png")
            print("Chart saved:", path if path else "Unavailable: install matplotlib or add records.")
        else:
            print("Invalid option.")
    except OSError as exc:
        print("Export failed:", exc)


def main():
    actions = {
        "1": add_record, "2": list_records, "3": search,
        "4": analytics, "5": exports, "6": import_csv,
    }
    while True:
        header()
        print("1. Add food waste record\n2. View records\n3. Search / filter records")
        print("4. Executive summary and warnings\n5. Export reports / chart")
        print("6. Import CSV dataset\n7. Exit")
        choice = input("\nSelect an option (1-7): ").strip()
        if choice == "7":
            storage.save(records)
            print("Data saved locally. Goodbye!")
            logger.info("CLI session closed")
            break
        action = actions.get(choice)
        if action:
            action()
        else:
            print("Choose a number from 1 to 7.")
        input("\nPress Enter to return to the menu...")


if __name__ == "__main__":
    main()
