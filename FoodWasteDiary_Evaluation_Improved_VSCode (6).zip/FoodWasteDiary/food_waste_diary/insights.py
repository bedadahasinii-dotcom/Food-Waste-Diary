"""Explainable waste-reduction insights derived only from recorded data."""
from .core import summarize


def build_insights(records, target_reduction=0.10):
    summary = summarize(records)
    insights = []
    if not records:
        return ["Add records to generate data-based waste-reduction insights."]
    if summary["by_category"]:
        category, amount = next(iter(summary["by_category"].items()))
        share = amount / summary["total_kg"] * 100 if summary["total_kg"] else 0
        insights.append(
            f"{category} is the largest recorded waste category ({amount:.3f} kg, {share:.1f}% of total). "
            f"Review purchasing and portion planning for this category first."
        )
    if summary["by_day"]:
        day, amount = max(summary["by_day"].items(), key=lambda item: item[1])
        insights.append(f"The highest-waste recorded day is {day} ({amount:.3f} kg). Review that day's meal and storage process.")
    target = summary["total_kg"] * target_reduction
    insights.append(
        f"A 10% reduction target would avoid approximately {target:.3f} kg "
        f"against the current recorded total of {summary['total_kg']:.3f} kg."
    )
    if summary["warnings"]:
        insights.append(f"There are {len(summary['warnings'])} threshold warning(s) to review.")
    else:
        insights.append("No configured threshold warnings were triggered by the current records.")
    return insights
