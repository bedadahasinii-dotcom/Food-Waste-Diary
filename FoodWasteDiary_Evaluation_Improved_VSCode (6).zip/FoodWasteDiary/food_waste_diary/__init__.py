"""Food Waste Diary application package."""
