"""CSV, Markdown, text and Matplotlib report generation."""
import csv
from pathlib import Path
from .storage import FIELDS
from .core import summarize


def export_csv(records, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)
    return path


def export_summary(records, path, fmt="md"):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    summary = summarize(records)
    lines = [
        "# Food Waste Diary Summary", "",
        f"- Records: {summary['entries']}",
        f"- Total waste: {summary['total_kg']:.3f} kg",
        f"- Average per record: {summary['average_kg']:.3f} kg",
        f"- Waste status: {summary['status']}", "",
        "## Waste by category",
    ]
    lines += [f"- {key}: {value:.3f} kg" for key, value in summary["by_category"].items()] or ["- No data yet"]
    lines += ["", "## Daily waste trend"]
    lines += [f"- {key}: {value:.3f} kg" for key, value in summary["by_day"].items()] or ["- No data yet"]
    lines += ["", "## Threshold warnings"]
    lines += [f"- {warning}" for warning in summary["warnings"]] or ["- No threshold warnings."]
    content = "\n".join(lines)
    if fmt == "txt":
        content = content.replace("# ", "").replace("## ", "\n")
    path.write_text(content, encoding="utf-8")
    return path


def make_chart(records, path):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    summary = summarize(records)
    if not summary["by_category"]:
        return None
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    figure, axis = plt.subplots(figsize=(8, 4.5))
    categories = list(summary["by_category"])
    values = list(summary["by_category"].values())
    axis.bar(categories, values)
    axis.set_title("Food Waste by Category")
    axis.set_ylabel("Waste (kg)")
    axis.tick_params(axis="x", rotation=25)
    figure.tight_layout()
    figure.savefig(path, dpi=160)
    plt.close(figure)
    return path
