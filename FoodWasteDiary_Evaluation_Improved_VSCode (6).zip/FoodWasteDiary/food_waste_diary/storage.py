"""SQLite-backed persistence with legacy JSON/CSV import and export mirrors.

SQLite is the source of truth. JSON and CSV are kept as portable backups so
older workflows and the original project brief remain supported.
"""
import csv
import json
import logging
import sqlite3
import threading
from contextlib import closing
from pathlib import Path
from uuid import uuid4

from .core import validate_record
from .logging_config import get_logger

logger = get_logger(__name__)
FIELDS = ["id", "food_name", "category", "quantity_kg", "reason", "entry_date"]
IMPORT_FIELDS = ["food_name", "category", "quantity_kg", "reason", "entry_date"]
_LOCK = threading.RLock()


class Storage:
    def __init__(self, data_dir="data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "records.json"
        self.csv_path = self.data_dir / "records.csv"
        self.db_path = self.data_dir / "food_waste.db"
        self._initialize_database()

    def _connect(self):
        conn = sqlite3.connect(self.db_path, timeout=15, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 15000")
        return conn

    def _initialize_database(self):
        with _LOCK, closing(self._connect()) as conn:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS records (
                    id TEXT PRIMARY KEY,
                    food_name TEXT NOT NULL CHECK(length(trim(food_name)) > 0),
                    category TEXT NOT NULL,
                    quantity_kg REAL NOT NULL CHECK(quantity_kg > 0),
                    reason TEXT NOT NULL,
                    entry_date TEXT NOT NULL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_records_date ON records(entry_date)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_records_category ON records(category)")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS schema_info (
                    version INTEGER NOT NULL
                )
            """)
            if conn.execute("SELECT COUNT(*) FROM schema_info").fetchone()[0] == 0:
                conn.execute("INSERT INTO schema_info(version) VALUES (1)")
        logger.info("Storage database ready at %s", self.db_path)

    def _read_legacy_json(self):
        if not self.json_path.exists():
            return None
        try:
            raw = json.loads(self.json_path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                raise ValueError("JSON root must be a list")
            records = []
            for item in raw:
                if not isinstance(item, dict):
                    continue
                try:
                    record = validate_record(
                        item.get("food_name"), item.get("category"),
                        item.get("quantity_kg"), item.get("reason"),
                        item.get("entry_date")
                    )
                    record["id"] = str(item.get("id") or record["id"])
                    records.append(record)
                except (ValueError, TypeError):
                    logger.warning("Skipped invalid legacy JSON record")
            return records
        except (json.JSONDecodeError, OSError, ValueError) as exc:
            backup = self.json_path.with_suffix(".corrupt.json")
            try:
                if not backup.exists():
                    self.json_path.replace(backup)
            except OSError:
                logger.exception("Could not back up corrupted JSON file")
            logger.warning("Legacy JSON could not be read; trying CSV recovery: %s", exc)
            return None

    def _read_legacy_csv(self):
        if not self.csv_path.exists():
            return []
        records = []
        try:
            with self.csv_path.open("r", newline="", encoding="utf-8-sig") as handle:
                reader = csv.DictReader(handle)
                if not reader.fieldnames or not set(FIELDS).issubset(set(reader.fieldnames)):
                    logger.warning("Legacy CSV has missing required columns")
                    return []
                for row in reader:
                    try:
                        record = validate_record(
                            row.get("food_name"), row.get("category"),
                            row.get("quantity_kg"), row.get("reason"),
                            row.get("entry_date")
                        )
                        record["id"] = str(row.get("id") or uuid4().hex[:8])
                        records.append(record)
                    except (ValueError, TypeError):
                        logger.warning("Skipped invalid legacy CSV row")
        except (OSError, UnicodeError, csv.Error):
            logger.exception("Could not read legacy CSV")
        return records

    def load(self):
        with _LOCK, closing(self._connect()) as conn:
            count = conn.execute("SELECT COUNT(*) FROM records").fetchone()[0]
            if count == 0:
                # Import legacy flat files only when the database is empty.
                records = self._read_legacy_json()
                if records is None:
                    records = self._read_legacy_csv()
                if records:
                    conn.execute("BEGIN IMMEDIATE")
                    try:
                        conn.executemany(
                            "INSERT OR IGNORE INTO records VALUES (:id,:food_name,:category,:quantity_kg,:reason,:entry_date)",
                            records,
                        )
                        conn.commit()
                    except Exception:
                        conn.rollback()
                        logger.exception("Legacy data migration failed")
                        raise
            result = [dict(row) for row in conn.execute(
                "SELECT id, food_name, category, quantity_kg, reason, entry_date "
                "FROM records ORDER BY entry_date, rowid"
            ).fetchall()]
        self._write_mirrors(result)
        logger.info("Loaded %d food waste record(s)", len(result))
        return result

    def save(self, records):
        # Validate before opening the write transaction: invalid data never reaches storage.
        clean = []
        seen = set()
        for item in records:
            record = validate_record(
                item.get("food_name"), item.get("category"), item.get("quantity_kg"),
                item.get("reason"), item.get("entry_date")
            )
            record["id"] = str(item.get("id") or record["id"])
            if record["id"] in seen:
                record["id"] = uuid4().hex[:8]
            seen.add(record["id"])
            clean.append(record)
        with _LOCK, closing(self._connect()) as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.execute("DELETE FROM records")
                conn.executemany(
                    "INSERT INTO records VALUES (:id,:food_name,:category,:quantity_kg,:reason,:entry_date)",
                    clean,
                )
                conn.commit()
            except Exception:
                conn.rollback()
                logger.exception("Database save failed; transaction rolled back")
                raise
        self._write_mirrors(clean)
        logger.info("Saved %d food waste record(s)", len(clean))

    def _atomic_write(self, path, writer):
        temp = path.with_suffix(path.suffix + ".tmp")
        writer(temp)
        temp.replace(path)

    def _write_mirrors(self, records):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        def write_json(path):
            path.write_text(json.dumps(records, indent=2, ensure_ascii=False), encoding="utf-8")
        def write_csv(path):
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=FIELDS)
                writer.writeheader()
                writer.writerows(records)
        with _LOCK:
            self._atomic_write(self.json_path, write_json)
            self._atomic_write(self.csv_path, write_csv)

    def import_csv(self, path):
        imported, errors = [], []
        try:
            with open(path, newline="", encoding="utf-8-sig") as handle:
                reader = csv.DictReader(handle)
                if not reader.fieldnames:
                    return [], ["CSV file is empty or has no header row."]
                missing = [field for field in IMPORT_FIELDS if field not in reader.fieldnames]
                if missing:
                    return [], ["Missing required CSV column(s): " + ", ".join(missing)]
                for line, row in enumerate(reader, start=2):
                    try:
                        imported.append(validate_record(
                            row.get("food_name"), row.get("category"),
                            row.get("quantity_kg"), row.get("reason"),
                            row.get("entry_date")
                        ))
                    except (ValueError, TypeError) as exc:
                        errors.append(f"Row {line}: {exc}")
        except (OSError, UnicodeError, csv.Error) as exc:
            logger.exception("CSV import failed")
            errors.append(f"Could not read CSV file: {exc}")
        logger.info("CSV import parsed %d valid row(s), %d issue(s)", len(imported), len(errors))
        return imported, errors
