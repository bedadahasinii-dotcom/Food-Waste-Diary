"""Central application logging configuration."""
import logging
from pathlib import Path


def configure_logging(log_dir="logs", level=logging.INFO):
    path = Path(log_dir)
    path.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    if not any(getattr(handler, "baseFilename", "").endswith("food_waste_diary.log")
               for handler in root.handlers):
        handler = logging.FileHandler(path / "food_waste_diary.log", encoding="utf-8")
        handler.setFormatter(logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        ))
        root.addHandler(handler)
    root.setLevel(level)


def get_logger(name):
    configure_logging()
    return logging.getLogger(name)
