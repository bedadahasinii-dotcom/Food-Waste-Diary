"""Validation and analytics for Food Waste Diary."""
from datetime import date
from uuid import uuid4
import math
import re

CATEGORIES = ["Fruit", "Vegetable", "Grain", "Dairy", "Meat", "Prepared", "Other"]
REASONS = ["Spoiled", "Expired", "Leftovers", "Over-prepared", "Damaged", "Other"]

# Demonstration thresholds; adjust these values to match a campus or household policy.
RECORD_WARNING_KG = 2.0
DAILY_WARNING_KG = 5.0
STATUS_LOW_KG = 5.0
STATUS_MODERATE_KG = 15.0


def validate_record(food_name, category, quantity, reason, entry_date):
    name = re.sub(r"\\s+", " ", str(food_name)).strip()
    name = "".join(ch for ch in name if ch.isprintable())
    category = str(category).strip().title()
    reason = str(reason).strip().title() or "Other"
    if not name:
        raise ValueError("Food name cannot be blank.")
    if len(name) > 80:
        raise ValueError("Food name must be 80 characters or fewer.")
    if category not in CATEGORIES:
        raise ValueError("Choose a valid category.")
    if reason not in REASONS:
        raise ValueError("Choose a valid reason.")
    try:
        quantity = float(quantity)
    except (ValueError, TypeError):
        raise ValueError("Quantity must be a number.")
    if not math.isfinite(quantity) or not 0 < quantity <= 1000:
        raise ValueError("Quantity must be greater than 0 and at most 1000 kg.")
    try:
        parsed_date = date.fromisoformat(str(entry_date))
    except (ValueError, TypeError):
        raise ValueError("Date must be a valid YYYY-MM-DD date.")
    return {
        "id": str(uuid4())[:8],
        "food_name": name,
        "category": category,
        "quantity_kg": round(quantity, 3),
        "reason": reason,
        "entry_date": parsed_date.isoformat(),
    }


def search_records(records, keyword="", category="All"):
    keyword = str(keyword).strip().lower()
    return [
        r for r in records
        if (not keyword or keyword in r["food_name"].lower() or keyword in r["reason"].lower())
        and (category == "All" or r["category"] == category)
    ]


def summarize(records):
    total = sum(float(r["quantity_kg"]) for r in records)
    by_category, by_day = {}, {}
    for record in records:
        category, day = record["category"], record["entry_date"]
        by_category[category] = by_category.get(category, 0) + float(record["quantity_kg"])
        by_day[day] = by_day.get(day, 0) + float(record["quantity_kg"])
    if total <= STATUS_LOW_KG:
        status = "Low"
    elif total <= STATUS_MODERATE_KG:
        status = "Moderate"
    else:
        status = "High"
    warnings = []
    for record in records:
        if float(record["quantity_kg"]) > RECORD_WARNING_KG:
            warnings.append(
                f"High single entry: {record['food_name']} is {float(record['quantity_kg']):.3f} kg "
                f"(warning threshold: {RECORD_WARNING_KG:.1f} kg)."
            )
    for day, amount in sorted(by_day.items()):
        if amount > DAILY_WARNING_KG:
            warnings.append(
                f"High daily total on {day}: {amount:.3f} kg "
                f"(warning threshold: {DAILY_WARNING_KG:.1f} kg)."
            )
    return {
        "entries": len(records),
        "total_kg": round(total, 3),
        "average_kg": round(total / len(records), 3) if records else 0,
        "by_category": dict(sorted(by_category.items(), key=lambda item: -item[1])),
        "by_day": dict(sorted(by_day.items())),
        "status": status,
        "warnings": warnings,
    }
