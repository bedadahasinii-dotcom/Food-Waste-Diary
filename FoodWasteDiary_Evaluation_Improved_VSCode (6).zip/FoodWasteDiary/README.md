# Food Waste Diary — Complete Python + Streamlit Project

This project keeps **both interfaces**:
- `main.py`: menu-driven terminal application.
- `app.py`: Streamlit browser interface for a visual demonstration.

The application uses **SQLite as its primary database**, with JSON and CSV backup mirrors for portability and compatibility with the original project requirements. It does not require an account, hosted database, or external API.

## Requirements

- Windows 10/11
- Python 3.10 or newer (Python 3.13/3.14 also supported)
- Internet connection only for the first installation of Python packages

## Run in VS Code (Windows PowerShell)

1. Extract the ZIP file.
2. In VS Code choose **File → Open Folder** and open the extracted `FoodWasteDiary` folder (the folder that contains `app.py`, `main.py`, and `requirements.txt`).
3. Choose **Terminal → New Terminal**.
4. Check Python:

   ```powershell
   py --version
   ```

   If `py` is not recognised, install Python from https://www.python.org/downloads/ and tick **Add Python to PATH**, then restart VS Code.

5. Create a virtual environment:

   ```powershell
   py -m venv .venv
   ```

6. Activate it:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks scripts, run:

   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   ```

   Then activate again. If activation is inconvenient, you can skip activation and use `.\.venv\Scripts\python.exe` for the commands below.

7. Install packages:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

8. Start the visual interface:

   ```powershell
   streamlit run app.py
   ```

   Or, without activating the environment:

   ```powershell
   .\.venv\Scripts\python.exe -m streamlit run app.py
   ```

   Streamlit normally opens `http://localhost:8501` in your browser. Keep the terminal open while using the app. Press `Ctrl+C` in the terminal to stop it.

Optional Windows shortcut: double-click `run_streamlit.bat` from File Explorer. It creates the virtual environment if needed, installs dependencies, and starts Streamlit.\n\n## Run the terminal interface

From the project folder, run:

```powershell
python main.py
```

The terminal menu supports adding records, viewing, searching/filtering, analytics and data-driven waste-reduction insights, report export, CSV import, and exit.

## Features mapped to the project brief

### Must-have requirements

1. **Interactive terminal interface:** menu-driven workflow in `main.py`.
2. **Defensive input validation:** non-empty food name, valid category/reason, numeric finite quantity between 0 and 1000 kg, valid ISO date.
3. **Core business logic:** shared validation, category totals, daily totals, averages, status and warnings in `food_waste_diary/core.py`.
4. **Persistent storage:** SQLite is the primary source of truth; JSON and CSV are refreshed as portable backup mirrors. Existing JSON/CSV data is migrated on first run. Malformed legacy JSON is backed up as `records.corrupt.json`, and CSV recovery is attempted.
5. **Record query and search:** keyword and category filtering.
6. **Executive summary:** record count, total, average, category breakdown, daily trends, overall status and warnings.
7. **Visual plotting:** Matplotlib chart saved as PNG and shown/downloadable in the Streamlit interface.

### Stretch requirements

- **Multi-format exports:** CSV records, Markdown summary, plain-text summary and PNG chart.
- **Threshold warnings:** a warning for an individual record above 2.0 kg and a daily total above 5.0 kg. These are demonstration thresholds, not official standards. Change `RECORD_WARNING_KG` and `DAILY_WARNING_KG` in `food_waste_diary/core.py` to customise them.
- **GUI enhancement:** Streamlit interface with dashboard, record entry, table view, search, CSV import and report downloads. This exceeds the optional Tkinter/Textual suggestion while retaining the terminal interface.
- **Data-driven action insights:** identifies the largest waste category and highest-waste day from recorded data, and calculates a 10% reduction target. These are transparent calculations, not AI-generated predictions.
- **Bulk CSV import:** checks required headers, validates each row, imports valid rows and reports row-specific errors.

## Sample dataset

`data/sample_food_waste.csv` and `data/sample_food_waste.json` contain the same **40 sample records**. They are demonstration data and are not automatically inserted into the live records. The set includes a minimum accepted quantity (0.001 kg) and a high-waste batch to demonstrate threshold warnings. To demonstrate bulk import, open **Reports & Export** in Streamlit and upload `data/sample_food_waste.csv`, or use option 6 in the terminal interface.

## Data and output locations

- `data/food_waste.db`: primary SQLite database (transactional writes, indexed date/category columns, WAL mode).
- `data/records.json`: JSON backup mirror.
- `data/records.csv`: CSV backup mirror.
- `logs/food_waste_diary.log`: structured application log.
- `data/sample_food_waste.csv` / `.json`: 40-row sample dataset.
- `exports/`: generated reports and chart files.
- `tests/`: automated unit tests.

## Evaluation-driven engineering improvements

- SQLite-backed persistence and legacy JSON/CSV migration.
- Structured logging to a rotating-independent local log file.
- Transactional writes, SQLite WAL, busy timeout and basic thread-level coordination.
- Additional storage, concurrency, migration, report integration and insight tests.
- GitHub Actions workflow at `.github/workflows/tests.yml` runs the test suite on pushes and pull requests.

## Run unit tests

```powershell
python -m unittest discover -s tests -v
```

## CSV import format

Required column names:

`food_name,category,quantity_kg,reason,entry_date`

Allowed categories: Fruit, Vegetable, Grain, Dairy, Meat, Prepared, Other.
Allowed reasons: Spoiled, Expired, Leftovers, Over-prepared, Damaged, Other.
Dates must use `YYYY-MM-DD`. Quantity must be a finite number greater than 0 and no more than 1000 kg.

## Suggested presentation demo

1. Launch the Streamlit interface.
2. Import `data/sample_food_waste.csv` to load 40 sample entries.
3. Show dashboard metrics, category chart, daily trend and threshold warnings.
4. Add a new entry; briefly demonstrate validation by trying a blank name or invalid value.
5. Search by food name and category.
6. Download the CSV, Markdown/TXT summary and chart.
7. Stop and restart the app, then show that records remain saved.
8. Optionally launch `python main.py` to demonstrate the required terminal interface.

## Notes

- Sample dataset import adds those rows to the live records. If you import it repeatedly, duplicate entries will be created.
- The threshold values are illustrative and should be explained as configurable demo limits.

### Concurrency note

SQLite serializes database write transactions and the application uses a busy timeout plus a process-local lock to reduce collisions. The app is intended for a single local demo/workstation; it is not a multi-user hosted service. If two separate app sessions edit the same old snapshot at once, the most recent full save can replace the earlier snapshot.
