import csv
import json
import tempfile
import unittest
from pathlib import Path

from food_waste_diary.core import validate_record, summarize, search_records
from food_waste_diary.storage import Storage
from food_waste_diary.reports import export_summary


class CoreTests(unittest.TestCase):
    def test_valid_record(self):
        record = validate_record("  Apple  ", "fruit", "0.25", "spoiled", "2026-11-21")
        self.assertEqual(record["food_name"], "Apple")
        self.assertEqual(record["category"], "Fruit")
        self.assertAlmostEqual(record["quantity_kg"], 0.25)

    def test_reject_zero_and_over_limit_quantity(self):
        for value in (0, -1, 1000.001, "not-a-number"):
            with self.assertRaises(ValueError):
                validate_record("Rice", "Grain", value, "Other", "2026-11-21")

    def test_accept_minimum_quantity(self):
        record = validate_record("Rice", "Grain", 0.001, "Other", "2026-11-21")
        self.assertEqual(record["quantity_kg"], 0.001)

    def test_reject_non_finite_quantity(self):
        for value in (float("nan"), float("inf")):
            with self.assertRaises(ValueError):
                validate_record("Rice", "Grain", value, "Other", "2026-11-21")

    def test_reject_bad_date_and_reason(self):
        with self.assertRaises(ValueError):
            validate_record("Rice", "Grain", 1, "Other", "bad-date")
        with self.assertRaises(ValueError):
            validate_record("Rice", "Grain", 1, "Unknown", "2026-11-21")

    def test_summary_and_status(self):
        data = [
            validate_record("Apple", "Fruit", 0.5, "Spoiled", "2026-11-20"),
            validate_record("Rice", "Grain", 1, "Leftovers", "2026-11-20"),
        ]
        result = summarize(data)
        self.assertEqual(result["entries"], 2)
        self.assertAlmostEqual(result["total_kg"], 1.5)
        self.assertEqual(result["status"], "Low")

    def test_threshold_warning(self):
        data = [validate_record("Rice", "Grain", 2.5, "Leftovers", "2026-11-20")]
        self.assertTrue(any("High single entry" in warning for warning in summarize(data)["warnings"]))

    def test_search_category(self):
        data = [validate_record("Apple", "Fruit", 0.5, "Spoiled", "2026-11-20")]
        self.assertEqual(len(search_records(data, "app", "Fruit")), 1)

    def test_corrupt_json_recovers_and_creates_clean_files(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Storage(folder)
            store.json_path.write_text("{bad json", encoding="utf-8")
            records = store.load()
            self.assertEqual(records, [])
            self.assertTrue(store.json_path.exists())
            self.assertTrue(store.csv_path.exists())
            self.assertTrue((Path(folder) / "records.corrupt.json").exists())

    def test_missing_json_creates_empty_storage(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Storage(folder)
            self.assertEqual(store.load(), [])
            self.assertTrue(store.json_path.exists())
            self.assertTrue(store.csv_path.exists())

    def test_csv_import_checks_headers_and_rows(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Storage(Path(folder) / "data")
            bad = Path(folder) / "bad.csv"
            bad.write_text("wrong,headers\na,b\n", encoding="utf-8")
            imported, errors = store.import_csv(bad)
            self.assertEqual(imported, [])
            self.assertTrue(errors)
            good = Path(folder) / "good.csv"
            good.write_text(
                "food_name,category,quantity_kg,reason,entry_date\n"
                "Apple,Fruit,0.2,Spoiled,2026-11-20\n"
                "Rice,Wrong,abc,Other,bad-date\n",
                encoding="utf-8",
            )
            imported, errors = store.import_csv(good)
            self.assertEqual(len(imported), 1)
            self.assertEqual(len(errors), 1)


    def test_sample_datasets_have_40_matching_rows(self):
        project_root = Path(__file__).resolve().parents[1]
        json_rows = json.loads((project_root / "data" / "sample_food_waste.json").read_text(encoding="utf-8"))
        with (project_root / "data" / "sample_food_waste.csv").open(encoding="utf-8", newline="") as handle:
            csv_rows = list(csv.DictReader(handle))
        self.assertEqual(len(json_rows), 40)
        self.assertEqual(len(csv_rows), 40)
        self.assertEqual(json_rows[0]["food_name"], csv_rows[0]["food_name"])

    def test_summary_export_contains_status_and_warnings_section(self):
        with tempfile.TemporaryDirectory() as folder:
            record = validate_record("Rice", "Grain", 2.5, "Leftovers", "2026-11-20")
            path = export_summary([record], Path(folder) / "summary.md")
            content = path.read_text(encoding="utf-8")
            self.assertIn("Waste status", content)
            self.assertIn("Threshold warnings", content)


if __name__ == "__main__":
    unittest.main()
