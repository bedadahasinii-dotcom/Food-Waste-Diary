import csv
import json
import tempfile
import threading
import unittest
from pathlib import Path

from food_waste_diary.core import validate_record
from food_waste_diary.storage import Storage
from food_waste_diary.insights import build_insights
from food_waste_diary.reports import export_csv, export_summary


class StorageIntegrationTests(unittest.TestCase):
    def make_record(self, food="Rice", kg=0.5, day="2026-11-20"):
        return validate_record(food, "Grain", kg, "Leftovers", day)

    def test_sqlite_save_load_and_backup_mirrors(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Storage(folder)
            expected = [self.make_record()]
            store.save(expected)
            loaded = store.load()
            self.assertEqual(len(loaded), 1)
            self.assertEqual(loaded[0]["food_name"], "Rice")
            self.assertTrue((Path(folder) / "food_waste.db").exists())
            self.assertTrue((Path(folder) / "records.json").exists())
            self.assertTrue((Path(folder) / "records.csv").exists())
            self.assertEqual(len(json.loads((Path(folder) / "records.json").read_text())), 1)

    def test_legacy_json_migrates_to_sqlite(self):
        with tempfile.TemporaryDirectory() as folder:
            record = self.make_record()
            Path(folder, "records.json").write_text(json.dumps([record]), encoding="utf-8")
            store = Storage(folder)
            loaded = store.load()
            self.assertEqual(len(loaded), 1)
            self.assertEqual(loaded[0]["food_name"], "Rice")
            self.assertTrue(Path(folder, "food_waste.db").exists())

    def test_concurrent_saves_do_not_corrupt_database(self):
        with tempfile.TemporaryDirectory() as folder:
            stores = [Storage(folder) for _ in range(4)]
            record = self.make_record()
            failures = []
            def writer(store):
                try:
                    for _ in range(5):
                        store.save([record])
                        store.load()
                except Exception as exc:
                    failures.append(exc)
            threads = [threading.Thread(target=writer, args=(store,)) for store in stores]
            for thread in threads: thread.start()
            for thread in threads: thread.join()
            self.assertEqual(failures, [])
            self.assertEqual(len(stores[0].load()), 1)

    def test_csv_import_and_report_exports(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Storage(Path(folder) / "data")
            source = Path(folder) / "input.csv"
            source.write_text(
                "food_name,category,quantity_kg,reason,entry_date\n"
                "Apple,Fruit,0.2,Spoiled,2026-11-20\n"
                "Bad,Invalid,xyz,Other,not-a-date\n",
                encoding="utf-8",
            )
            imported, errors = store.import_csv(source)
            self.assertEqual(len(imported), 1)
            self.assertEqual(len(errors), 1)
            store.save(imported)
            csv_out = export_csv(imported, Path(folder) / "exports" / "records.csv")
            md_out = export_summary(imported, Path(folder) / "exports" / "summary.md")
            self.assertTrue(csv_out.exists())
            self.assertIn("Waste status", md_out.read_text(encoding="utf-8"))

    def test_data_driven_action_insights(self):
        insights = build_insights([self.make_record("Rice", 2.5)])
        self.assertTrue(any("10% reduction target" in item for item in insights))
        self.assertTrue(any("largest recorded waste category" in item for item in insights))


if __name__ == "__main__":
    unittest.main()
