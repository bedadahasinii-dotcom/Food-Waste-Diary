from datetime import date
from pathlib import Path
import pandas as pd
import streamlit as st

from food_waste_diary.core import (
    validate_record, search_records, summarize, CATEGORIES, REASONS,
    RECORD_WARNING_KG, DAILY_WARNING_KG, STATUS_LOW_KG, STATUS_MODERATE_KG,
)
from food_waste_diary.storage import Storage
from food_waste_diary.reports import export_csv, export_summary, make_chart
from food_waste_diary.insights import build_insights
from food_waste_diary.logging_config import get_logger

logger = get_logger(__name__)

ROOT = Path(__file__).resolve().parent
storage = Storage(ROOT / "data")
st.set_page_config(page_title="Food Waste Diary", page_icon="🥗", layout="wide")


def save_records(items):
    storage.save(items)


records = storage.load()
st.title("🥗 Food Waste Diary")
st.caption("A local Python application to record discarded food, analyse waste patterns and export reports.")
st.divider()

with st.sidebar:
    st.header("Navigation")
    page = st.radio(
        "Choose a section",
        ["Dashboard", "Add Record", "All Records", "Search & Filter", "Reports & Export", "About & Thresholds"],
    )
    st.divider()
    st.caption("SQLite database with JSON/CSV backup mirrors")
    st.code("data/food_waste.db\ndata/records.json\ndata/records.csv", language="text")
    st.caption("No cloud account or external database is used.")

summary = summarize(records)

if page == "Dashboard":
    st.subheader("Waste overview")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total records", summary["entries"])
    c2.metric("Total food waste", f'{summary["total_kg"]:.3f} kg')
    c3.metric("Average per record", f'{summary["average_kg"]:.3f} kg')
    c4.metric("Waste status", summary["status"])
    st.caption(f"Status bands: Low ≤ {STATUS_LOW_KG:.1f} kg · Moderate ≤ {STATUS_MODERATE_KG:.1f} kg · High > {STATUS_MODERATE_KG:.1f} kg")
    if summary["warnings"]:
        st.warning("Threshold warnings")
        for warning in summary["warnings"]:
            st.write(f"⚠️ {warning}")
    else:
        st.success("No threshold warnings for the current records.")
    left, right = st.columns(2)
    with left:
        st.markdown("#### Waste by category")
        if summary["by_category"]:
            chart_data = pd.DataFrame(
                [{"Category": key, "Waste (kg)": value} for key, value in summary["by_category"].items()]
            ).set_index("Category")
            st.bar_chart(chart_data)
            highest = next(iter(summary["by_category"].items()))
            st.info(f"Highest waste category: **{highest[0]}** ({highest[1]:.3f} kg)")
        else:
            st.info("No records yet. Add your first food waste entry.")
    with right:
        st.markdown("#### Daily waste trend")
        if summary["by_day"]:
            daily = pd.DataFrame(
                [{"Date": pd.to_datetime(key), "Waste (kg)": value} for key, value in summary["by_day"].items()]
            ).set_index("Date")
            st.line_chart(daily)
        else:
            st.info("Daily trend will appear after you add records.")
    st.markdown("#### Waste reduction action insights")
    for insight in build_insights(records):
        st.write(f"💡 {insight}")
    if records:
        st.markdown("#### Recent entries")
        recent = sorted(records, key=lambda item: item["entry_date"], reverse=True)[:8]
        st.dataframe(
            pd.DataFrame(recent)[["entry_date", "food_name", "category", "quantity_kg", "reason"]],
            use_container_width=True, hide_index=True,
        )

elif page == "Add Record":
    st.subheader("Add food waste record")
    with st.form("add_record_form", clear_on_submit=True):
        col1, col2 = st.columns(2)
        with col1:
            food_name = st.text_input("Food name", max_chars=80, placeholder="e.g. Rice, Apple, Bread")
            category = st.selectbox("Category", CATEGORIES)
            quantity = st.number_input(
                "Discarded quantity (kg)", min_value=0.001, max_value=1000.0,
                value=0.250, step=0.050, format="%.3f",
            )
        with col2:
            reason = st.selectbox("Reason", REASONS)
            entry_date = st.date_input("Date", value=date.today())
        submitted = st.form_submit_button("Save record", type="primary")
        if submitted:
            try:
                record = validate_record(food_name, category, quantity, reason, entry_date.isoformat())
                records.append(record)
                save_records(records)
                st.success("Record saved to SQLite with JSON and CSV backup copies.")
                logger.info("Streamlit record added: %s", record["id"])
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))

elif page == "All Records":
    st.subheader("All food waste records")
    if records:
        frame = pd.DataFrame(records)[["entry_date", "food_name", "category", "quantity_kg", "reason", "id"]]
        st.dataframe(frame, use_container_width=True, hide_index=True)
        st.caption(f"{len(records)} record(s)")
        with st.expander("Delete records"):
            st.warning("Deleting all records cannot be undone.")
            if st.button("Delete all records", type="secondary"):
                save_records([])
                st.success("All records deleted.")
                st.rerun()
    else:
        st.info("No records found. Use Add Record to create one.")

elif page == "Search & Filter":
    st.subheader("Search and filter records")
    col1, col2 = st.columns([2, 1])
    with col1:
        keyword = st.text_input("Search food name or reason", placeholder="Type a keyword")
    with col2:
        category_filter = st.selectbox("Category", ["All"] + CATEGORIES)
    filtered = search_records(records, keyword, category_filter)
    if filtered:
        st.dataframe(
            pd.DataFrame(filtered)[["entry_date", "food_name", "category", "quantity_kg", "reason"]],
            use_container_width=True, hide_index=True,
        )
        st.caption(f"Found {len(filtered)} matching record(s)")
    else:
        st.info("No matching records.")

elif page == "Reports & Export":
    st.subheader("Reports and export")
    st.write("Download structured records, summaries and visual charts.")
    if records:
        csv_path = export_csv(records, ROOT / "exports" / "food_waste_export.csv")
        md_path = export_summary(records, ROOT / "exports" / "summary.md", "md")
        txt_path = export_summary(records, ROOT / "exports" / "summary.txt", "txt")
        col1, col2, col3 = st.columns(3)
        col1.download_button("⬇️ Records CSV", csv_path.read_bytes(), "food_waste_export.csv", "text/csv", use_container_width=True)
        col2.download_button("⬇️ Summary Markdown", md_path.read_text(encoding="utf-8"), "food_waste_summary.md", "text/markdown", use_container_width=True)
        col3.download_button("⬇️ Summary TXT", txt_path.read_text(encoding="utf-8"), "food_waste_summary.txt", "text/plain", use_container_width=True)
        chart_path = make_chart(records, ROOT / "exports" / "category_chart.png")
        if chart_path and chart_path.exists():
            st.image(str(chart_path), caption="Matplotlib: food waste by category", use_container_width=True)
            st.download_button("⬇️ Download chart PNG", chart_path.read_bytes(), "food_waste_category_chart.png", "image/png")
    else:
        st.info("Add records first. Export options will appear here.")
    st.divider()
    st.markdown("#### Bulk import CSV dataset")
    st.caption("Required headers: food_name, category, quantity_kg, reason, entry_date. Invalid rows are skipped and listed.")
    uploaded = st.file_uploader("Choose a CSV file", type=["csv"])
    if uploaded is not None and st.button("Import valid rows"):
        import tempfile
        temp_path = ROOT / "data" / "_upload_temp.csv"
        temp_path.write_bytes(uploaded.getvalue())
        imported, errors = storage.import_csv(temp_path)
        temp_path.unlink(missing_ok=True)
        if imported:
            records.extend(imported)
            save_records(records)
            st.success(f"Imported {len(imported)} valid row(s).")
        if errors:
            st.warning(f"{len(errors)} row/file issue(s) found:")
            for error in errors:
                st.write(f"- {error}")
        if not imported and not errors:
            st.info("No data rows were found in the uploaded CSV.")
        st.rerun()

elif page == "About & Thresholds":
    st.subheader("Project information")
    st.write("Food Waste Diary is a Python application with both a terminal menu and a Streamlit graphical interface.")
    st.markdown("#### Configured demonstration thresholds")
    st.write(f"- Single record warning: more than **{RECORD_WARNING_KG:.1f} kg**")
    st.write(f"- Daily total warning: more than **{DAILY_WARNING_KG:.1f} kg**")
    st.write(f"- Overall status: Low up to **{STATUS_LOW_KG:.1f} kg**, Moderate up to **{STATUS_MODERATE_KG:.1f} kg**, High above that")
    st.caption("These are example thresholds for demonstration. Change the constants in food_waste_diary/core.py to suit your institution's policy.")
    st.markdown("#### Technology")
    st.write("Python · Streamlit · Pandas · Matplotlib · SQLite · JSON/CSV backups · Python logging")
    st.markdown("#### Data files")
    st.code("data/records.json  — primary structured record file\ndata/records.csv   — CSV copy\ndata/sample_food_waste.json — 40-row sample dataset\ndata/sample_food_waste.csv  — matching CSV sample")
    st.markdown("#### Demo checklist")
    st.write("1. Add a food waste entry. 2. Try a blank name or invalid quantity. 3. View dashboard and warnings. 4. Search by keyword/category. 5. Export reports. 6. Import the sample CSV. 7. Restart the app and confirm records remain.")

st.divider()
st.caption("Food Waste Diary • Python + Streamlit • Records are stored locally on this computer.")
